const admin = require('firebase-admin');

config = {
    apiKey: "AIzaSyA7aWA4TJKomLttdx95AhN5Rb9iExY5CNY",
    authDomain: "socialape2-eb209.firebaseapp.com",
    databaseURL: "https://socialape2-eb209.firebaseio.com",
    projectId: "socialape2-eb209",
    storageBucket: "socialape2-eb209.appspot.com",
    messagingSenderId: "235436950990",
    appId: "1:235436950990:web:a4efa824f8d901955f979f",
    measurementId: "G-TBFPEM8K7J"
  };

module.exports = {admin};