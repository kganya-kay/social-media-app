let db = {
    screams: [
        {
            userHandle: 'user',
            body: 'this is the body of the scream',
            createdAt: "2020-01-19T17:16:52.416Z",
            likeCount: 5,
            commentComment: 2
        }
    ]
}